const b=document.getElementById('menuBtn');
const m=document.getElementById('mobileMenu');
if(b){b.onclick=()=>m.classList.toggle('hidden');}
